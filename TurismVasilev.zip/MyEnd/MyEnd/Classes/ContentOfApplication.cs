﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;

namespace MyEnd.Classes
{
    public class ContentOfApplication
    {
        public static MainWindow mainWindow;
        public static void FillingTheWindow(bool IsChecked = false)
        {
            using (Entities db = new Entities())
            {
                foreach (Tour tour in db.Tour)
                {
                    if (IsChecked == true && tour.IsActual == false)
                    {

                    }
                    else
                    {
                        //Border border = new Border();
                        //border.Height = 200;
                        //border.Width = 250;
                        //border.Background = new SolidColorBrush(Colors.LightBlue);
                        StackPanel stackPanel = new StackPanel();
                        stackPanel.Background = new SolidColorBrush(Colors.Orange);
                        stackPanel.Orientation = Orientation.Vertical;
                        stackPanel.HorizontalAlignment = HorizontalAlignment.Left;
                        stackPanel.Height = 200;
                        stackPanel.Width = 230;
                        stackPanel.Margin = new Thickness(5, 0, 5, 5);
                        //Label label = new Label();
                        //label.FontSize = 12;
                        //label.Foreground = new SolidColorBrush(Colors.Yellow);
                        //label.Content = tour.Name;//Берем название тура из БД 
                        //label.HorizontalAlignment = HorizontalAlignment.Center;
                        TextBlock textBlock = new TextBlock();
                        textBlock.FontSize = 15;
                        textBlock.Foreground = new SolidColorBrush(Colors.Blue);
                        textBlock.Text = tour.Name;
                        textBlock.FontFamily = new FontFamily("Comic Sans MS");
                        textBlock.Background = new SolidColorBrush(Colors.Transparent);
                        if (textBlock.Text.Length >= 17)
                        {
                            textBlock.HorizontalAlignment = HorizontalAlignment.Left;
                            textBlock.TextWrapping = TextWrapping.Wrap;
                        }
                        else
                            textBlock.HorizontalAlignment = HorizontalAlignment.Left;
                        //BitmapImage bitmapImage = new BitmapImage();
                        //bitmapImage = LoadImage(tour.ImagePreview);//загружаем изображение из БД
                        //Image image = new Image();
                        //image.Source = bitmapImage;
                        //image.Width = 220;
                        //image.Height = 100;
                        var stream = new MemoryStream(tour.ImagePreview);
                        var image = new BitmapImage();
                        image.BeginInit();
                        image.StreamSource = stream;
                        image.EndInit();
                        Image image1 = new Image();
                        image1.Source = image;
                        image1.Height = 100;
                        image1.Width = 210;
                        Label label2 = new Label();
                        label2.FontSize = 12;
                        label2.Foreground = new SolidColorBrush(Colors.Black);
                        label2.Content = tour.Price;//Загрузка цены из БД
                        label2.HorizontalAlignment = HorizontalAlignment.Center;
                        StackPanel stackPanel2 = new StackPanel();
                        stackPanel2.Orientation = Orientation.Horizontal;
                        stackPanel2.HorizontalAlignment = HorizontalAlignment.Center;
                        Label label3 = new Label();
                        label3.FontSize = 11;
                        if (tour.IsActual)
                        {
                            label3.Foreground = new SolidColorBrush(Colors.Green);
                            label3.Content = "Актуален";
                        }
                        else
                        {
                            label3.Foreground = new SolidColorBrush(Colors.Red);
                            label3.Content = "Не актуален";
                        }
                        label3.Margin = new Thickness(0, 0, 30, 0);
                        Label label4 = new Label();
                        label4.FontSize = 11;
                        label4.Foreground = new SolidColorBrush(Colors.Black);
                        label4.Margin = new Thickness(30, 0, 0, 0);
                        label4.Content = "Билетов:" + Convert.ToString(tour.TicketCount);
                        stackPanel2.Children.Add(label3);
                        stackPanel2.Children.Add(label4);
                        stackPanel.Children.Add(textBlock);
                        stackPanel.Children.Add(image1);
                        stackPanel.Children.Add(label2);
                        stackPanel.Children.Add(stackPanel2);
                        Grid grid = new Grid();
                        //grid.Children.Add(border);
                        grid.Children.Add(stackPanel);
                        mainWindow.MainWrapPanel.Children.Add(grid);
                    }
                }
            }

        }
        //public static BitmapImage LoadImage(byte[] imageData)
        //{
        //    if (imageData == null || imageData.Length == 0) return null;
        //    var image = new BitmapImage();
        //    using (var mem = new MemoryStream(imageData))
        //    {
        //        mem.Position = 0;
        //        image.BeginInit();
        //        image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
        //        image.CacheOption = BitmapCacheOption.OnLoad;
        //        image.UriSource = null;
        //        image.StreamSource = mem;
        //        image.EndInit();
        //    }
        //    image.Freeze();
        //    return image;
        //}

    }
}
